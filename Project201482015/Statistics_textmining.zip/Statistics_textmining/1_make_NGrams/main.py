__author__ = 'pshort'

from lxml import etree
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.stem.wordnet import WordNetLemmatizer
from unidecode import unidecode
import sys


#Using biopython to get pubmed metadata from NCBI

def get_pubmed_metadata(xmlfile):
    """
    use biopython.entrez to return pubmed metadata as a dict
    """

    # post_size = len(pmid_list)
    # print('Preparing to post %i requests to PubMed.' % post_size)
    # Entrez.email = email
    # Entrez.tool = 'biopython'
    # search_results = Entrez.read(Entrez.epost("pubmed", id=",".join(pmid_list)))
    # webenv = search_results["WebEnv"]
    # query_key = search_results["QueryKey"]
    batch_size = 500
    total_words = 0
    punc = [",", ".", "/", ";", "'", "?", "&", "-", ")", "(", "\"", "\\"]

    pmid2abstract_data = {}
    pmid2authors_data = {}
    pmid2affil_data = {}
    pmid2mesh_data = {}
    pmid2journal_data = {}
    pmid2print_medium = {}

    xml_data = xmlfile
    tree = etree.parse(xml_data)
    root = tree.getroot()

    for article in root:
        pmid = article.find('.//PMID').text
        abstract = {}
        try:
            abtext = article.find('.//AbstractText').text
            # abtext = abtext.split(" ")
            # total_words += len(abtext)
            # for word in abtext:
            #     for p in punc:
            #         word = word.replace(p, "")
            #     if word not in abstract:
            #         abstract[word] = 1
            pmid2abstract_data[pmid] = abtext
        except AttributeError:
            pmid2abstract_data[pmid] = ['None']
            pass
        authors = {}
        try:
            author_total = article.find('.//AuthorList')
            for author in author_total:
                lastname = author[0].text
                if len(author) > 1:
                    firstname = author[1].text
                    name = unicode(firstname) + " " + unicode(lastname)
                else:
                    name = lastname
                name = name.replace("\"", "")
                if name not in authors:
                    authors[name] = 1
            pmid2authors_data[pmid] = authors.keys()
        except:
            pmid2authors_data[pmid] = ['None']
            pass
        try:
            affiliation = article.find('.//Affiliation').text
            affiliation_list = affiliation.split(",")
            if len(affiliation_list) > 1:
                affiliation = affiliation_list[0] + ", " + affiliation_list[1]
            pmid2affil_data[pmid] = affiliation
        except AttributeError:
            pmid2affil_data[pmid] = 'None'
            pass
        mesh_headings = {}
        try:
            mesh_list = article.find('.//MeshHeadingList')
            for mesh in mesh_list:
                mesh_descriptor = mesh[0].text
                if mesh_descriptor not in mesh_headings:
                    mesh_headings[mesh_descriptor] = 1
            pmid2mesh_data[pmid] = mesh_headings.keys()
        except AttributeError and TypeError:
            pmid2mesh_data[pmid] = ['None']
            pass
        try:
            title = article.find('.//Title').text
            pmid2journal_data[pmid] = title
        except AttributeError:
            pmid2journal_data[pmid] = 'None'
            pass
        try:
            medium = article.find('.//JournalIssue').get('CitedMedium')
            pmid2print_medium[pmid] = medium
        except AttributeError:
            pmid2print_medium[pmid] = 'None'
            pass

    pmid2metadata = {}
    for pmid in pmid2authors_data:
        data_dict = {'author': pmid2authors_data[pmid], 'journal': pmid2journal_data[pmid],
                     'affiliation': pmid2affil_data[pmid],
                     'abs_word': pmid2abstract_data[pmid], 'mesh_head': pmid2mesh_data[pmid],
                     'print_med': pmid2print_medium[pmid]}
        pmid2metadata[pmid] = data_dict

    return pmid2metadata



#nombre de indice invertido se recibe como argumento
results = []
filename=sys.argv[1]
if filename: results = get_pubmed_metadata(filename)
else: results = get_pubmed_metadata("pubmed_result_PTSD_Fanny.xml")


# ==== StopWords ====
from SemanticProc import StopWords
make=StopWords()
make.DefaultStopwords("english")
make.CustomStopwords("stopwordsProfe.txt")
stopwords=make.stopwords.keys()
# ==== / StopWords ====


from SemanticProc import SemanticProcessing
build=SemanticProcessing()
for i in results:	
	abstr = results[i]["abs_word"]
	# print abstr
	if build.isAbstract(abstr):
		conc = abstr.replace("\n"," ")
		# print conc

		# raw=nltk.clean_html(conc)
		raw=unidecode(conc)
		raw=raw.replace("e.g.","")
		raw=raw.replace("i.e.","")
		tokenizer = RegexpTokenizer(r'\w+')
		tokens=tokenizer.tokenize(raw)
		try: text=nltk.Text(tokens)
		except: print i+": fail in nltk.Text(tokens)"
		words=[w.lower() for w in text]
		words = [token for token in words if token not in stopwords]
		words = [token for token in words if not build.is_number(token)]
		if len(words)>0: 
			#		c.writerow([i," ".join(words)])
			##		if len(words)==10: break
			build.Monograms(i,words)
			build.Bigrams(i,words)
		else: 
			print "rien: "+i
	## ===== < / N-GRAMS > ===== ##


#print "===== < GUARDAR > ====="
## ===== < GUARDAR > ===== ##
A=build.FrecArray_monograms
iimgs=build.save(A,"monograms")
B=build.FrecArray_bigrams
iibgs=build.save(B,"bigrams")
#print "===== < / GUARDAR > ====="
## ===== < / GUARDAR > ===== ##

#print "-------------------------------------------------"
print iimgs+" "+iibgs