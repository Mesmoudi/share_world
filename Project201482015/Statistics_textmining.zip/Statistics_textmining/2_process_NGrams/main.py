

import numpy
from readInvInd import parseInvInd
import sys
from NetworkMetrics import makeNetwork
from InterUnion import Inter_Union
import math


#nombre de indice invertido se recibe como argumento
filename=sys.argv[1]
ii=parseInvInd(filename)
ii.build__Pub_x_Terms()
filename=filename.replace(".txt","")

pub_terms=ii.pub_terms
term_occs=ii.term_occs
term_pubs=ii.term_pubs
TERM=ii.TERM # diccionario   id termino <=> nombre termino

netw=makeNetwork()
for idpub in pub_terms:
	terms=pub_terms[idpub]
	netw.addCompleteSubGraph(idpub,terms)


import time
start_time = time.time()
#OCURRENCIAS y TFIDF
FINAL={}
info = ii.build__RAW()
N=len(pub_terms.keys())
print "pubs:",N
print "terms:",len(netw.G)


for i in term_occs:
	maxFij=float(info[TERM[i]][0]) #max doc
	docus=info[TERM[i]]
	ni=float(len(docus)+1)
	suma = 0
	tfidfs=[]
	idf = math.log10( N / ni)
#	print "N:",N,"ni:",ni,"idf:",idf
	for Fij in docus:
		tf = (Fij / maxFij)
		tfidf = tf * idf
#		print "tf:",tf
		tfidfs.append(tfidf)
	prom = round(sum(tfidfs)/float(len(tfidfs)),4)
	stdv = round(numpy.std(tfidfs),4)
#	print TERM[i],prom,stdv #TF-IDF
	FINAL[i]={"o":term_occs[i],"cp":0.0,"cd":0.0,"jp":0.0,"jd":0.0,"tp":prom,"td":stdv}
#	print TERM[i]+"\t"+`term_occs[i]`
print filename+" occs+tfidf END", (time.time() - start_time), "seconds"


start_time = time.time()
#COOCURRENCIAS
G=netw.G
for i in G.nodes_iter():
	FINAL[i]["cp"]=0.0
	FINAL[i]["cd"]=0.0
	neig=G.neighbors(i)
	if len(neig)!=0:
		weights= []
		for j in neig:
			w=G[i][j]['weight']
			weights.append(w)
		prom = round(sum(weights)/float(len(weights)),4)
		stdv = round(numpy.std(weights),4)
		FINAL[i]["cp"]=prom
		FINAL[i]["cd"]=stdv
print filename+"  cooccs END", (time.time() - start_time), "seconds"




start_time = time.time()
# JACCARD
term_jaccards={}
def pushJacc(n1,n2,jacc):
	if not term_jaccards.has_key(n1):
		term_jaccards[n1]=[]
	term_jaccards[n1].append(jacc)
	
	if not term_jaccards.has_key(n2):
		term_jaccards[n2]=[]
	term_jaccards[n2].append(jacc)

G=netw.G
calc=Inter_Union()
for n in G.edges_iter():
	n1=n[0]
	n2=n[1]
#	print TERM[n1],TERM[n2]
	Pn1=sorted(term_pubs[n1].keys())
	Pn2=sorted(term_pubs[n2].keys())
#	print Pn1
#	print Pn2
	inter=calc.intersect(Pn1,Pn2)
	if inter!=0:
		union=calc.union(Pn1,Pn2)
#		print "\tintersect",inter
#		print "\tunion",union
		jacc=round(len(inter)/float(len(union)),4)
#		print "\t\tjaccard",jacc
		pushJacc(n1,n2,jacc)

for i in term_jaccards:
	jaccs=term_jaccards[i]
#	print TERM[i],jaccs
	prom=round((sum(jaccs)/float(len(jaccs))),4)
	stdv=round(numpy.std(jaccs),4)
	FINAL[i]["jp"]=prom
	FINAL[i]["jd"]=stdv
#	print "\t",prom,stdv

print filename+" jaccard END", (time.time() - start_time), "seconds"

## PAGE RANK
#import networkx as nx
#GPR=nx.pagerank(netw.G)
#print filename+" pagerank END", (time.time() - start_time), "seconds\n"

import csv
c = csv.writer(open(filename+".csv", "wb"),delimiter='\t')
c.writerow(["term","occ","cooc prom","cooc stdv", "tfidf prom", "tfidf stdv", "jacc prom","jacc stdv"])
for i in FINAL:
	A=FINAL[i]
	occ=A["o"]
#	pagerank='{0:.10f}'.format(GPR[i]).replace(".",",")
	coocP=`A["cp"]`.replace(".",",")
	coocS=`A["cd"]`.replace(".",",")
	tfidfP=`A["tp"]`.replace(".",",")
	tfidfS=`A["td"]`.replace(".",",")
	jaccP=`A["jp"]`.replace(".",",")
	jaccS=`A["jd"]`.replace(".",",")
	print TERM[i],occ,coocP,coocS,tfidfP,tfidfS,jaccP,jaccS
	c.writerow([TERM[i],occ,coocP,coocS,tfidfP,tfidfS,jaccP,jaccS])


