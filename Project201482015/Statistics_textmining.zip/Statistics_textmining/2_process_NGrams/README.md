Calcula ocurrencias y co-ocurrencias a partir de un indice invertido (test.txt)

Modo de uso:

python main.py "InvDict_bigrams.txt"
